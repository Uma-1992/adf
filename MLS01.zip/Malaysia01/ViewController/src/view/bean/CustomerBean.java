package view.bean;

import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;

import oracle.adf.view.rich.component.rich.fragment.RichRegion;

import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;
import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;
import oracle.adf.view.rich.component.rich.nav.RichCommandButton;
import oracle.adf.view.rich.component.rich.nav.RichCommandLink;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding;

import oracle.jbo.domain.Number;

public class CustomerBean {
    private Number customerId;
    private RichRegion customerTFBind;
    private RichRegion stockTFBind;
    private Number productId;
    private Integer creditvalue;
    private RichRegion creditTFBind;
   // private boolean buttonsVisible = true;

    public void searchAL(ActionEvent actionEvent) {
        // Add event code here...
        Number id = this.getCustomerId();
        //calling AM method
        OperationBinding ob =
            BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("fetchCustomers");
        //Passing arguments to the AM method
        ob.getParamsMap().put("custId", id);
        //executing the AM method
        ob.execute();
//        if (id != null) {
           // buttonsVisible = false;
            // putting visible false to the customerTF as region
            this.getCustomerTFBind().setVisible(true);
            this.getCreditTFBind().setVisible(false);
            this.getStockTFBind().setVisible(false);
           
//        } else {
//            buttonsVisible = true;
//        }
        //programaticlly refreshing customer TF as region
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getStockTFBind());
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getCustomerTFBind());
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getCreditTFBind());
    }

    public void setCustomerId(Number customerId) {
        this.customerId = customerId;
    }

    public Number getCustomerId() {
        return customerId;
    }

    public void setCustomerTFBind(RichRegion customerTFBind) {
        this.customerTFBind = customerTFBind;
    }

    public RichRegion getCustomerTFBind() {
        return customerTFBind;
    }

    public void hideCustomerRegionACL(ActionEvent actionEvent) {
        // Add event code here...

        System.out.println("Entering TF ...............");
        // putting visible false to the customerTF as region

        this.getCustomerTFBind().setVisible(false);
        this.getStockTFBind().setVisible(false);
        this.getCreditTFBind().setVisible(false);
        //programaticlly refreshing customer TF as region
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getStockTFBind());
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getCustomerTFBind());
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getCreditTFBind());

    }

    public void setStockTFBind(RichRegion stockTFBind) {
        this.stockTFBind = stockTFBind;
    }

    public RichRegion getStockTFBind() {
        return stockTFBind;
    }

    public void setProductId(Number productId) {
        this.productId = productId;
    }

    public Number getProductId() {
        return productId;
    }

    public void hidestockRegionACL(ActionEvent actionEvent) {
        // Add event code here...
        // putting visible false to the customerTF as region
        this.getCustomerTFBind().setVisible(false);
        this.getStockTFBind().setVisible(false);
        this.getCreditTFBind().setVisible(false);
        //programaticlly refreshing customer TF as region

        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getStockTFBind());
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getCustomerTFBind());
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getCreditTFBind());

    }

    public void searchProductAL(ActionEvent actionEvent) {
        // Add event code here...

        //calling AM method
        OperationBinding ob =
            BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("fetchProducts");
        //Passing arguments to the AM method
        ob.getParamsMap().put("product", this.getProductId());
        //executing the AM method
        ob.execute();
       // buttonsVisible = false;
        // putting visible true to the StockTFTF as region
        this.getStockTFBind().setVisible(true);
        this.getCustomerTFBind().setVisible(false);
        this.getCreditTFBind().setVisible(false);
        //programaticlly refreshing StockTF TF as region
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getStockTFBind());


    }

    public void creditRatingSearchACL(ActionEvent actionEvent) {
        // Add event code here...
        //calling AM method
        OperationBinding ob =
            BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("fetchCreditRating");
        //Passing arguments to the AM method
        ob.getParamsMap().put("creditId", this.getCreditvalue());
        //executing the AM method
        ob.execute();
    // buttonsVisible = false;
     // putting visible true to the StockTFTF as region
     this.getCreditTFBind().setVisible(true);
     this.getStockTFBind().setVisible(false);
     this.getCustomerTFBind().setVisible(false);
  
        // putting visible true to the StockTFTF as region
       
        //programaticlly refreshing StockTF TF as region
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getCreditTFBind());
 }


    public void setCreditTFBind(RichRegion creditTFBind) {
        this.creditTFBind = creditTFBind;
    }

    public RichRegion getCreditTFBind() {
        return creditTFBind;
    }

    public void showAllCustomerDetails(ActionEvent actionEvent) {
        // Add event code here...
        this.getCreditTFBind().setVisible(true);
        System.out.println("CreditTFBind.......................................");

        this.getCustomerTFBind().setVisible(true);
        //this.getOperationGroupBind().setVisible(true);
        System.out.println("CustomerTFBind................................");


        this.getStockTFBind().setVisible(true);
        System.out.println("StockTFBind...............................................");
        
        System.out.println("Clearing Customer id");
        OperationBinding ob =
            BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("fetchCustomers");
        ob.execute();
        
        System.out.println("Cleared Customers Id");
//        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("x", "Hi");
//        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("y", "Hello");
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getStockTFBind());
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getCustomerTFBind());
        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getCreditTFBind());
    }

    public void setCreditvalue(Integer creditvalue) {
        this.creditvalue = creditvalue;
    }

    public Integer getCreditvalue() {
        return creditvalue;
    }

//    public void setButtonsVisible(boolean buttonsVisible) {
//        this.buttonsVisible = buttonsVisible;
//    }
//
//    public boolean isButtonsVisible() {
//        return buttonsVisible;
//    }
}
