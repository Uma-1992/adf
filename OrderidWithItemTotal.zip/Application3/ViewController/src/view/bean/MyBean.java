package view.bean;

import java.math.BigDecimal;

import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.view.rich.component.rich.output.RichOutputText;

import oracle.jbo.Row;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaManager;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Number;

public class MyBean {
    private RichOutputText result;
    private Number ordId;
    
    

    public MyBean() {
    }


    public void searchButton(ActionEvent actionEvent) {
        // Add event code here...
        System.out.println("Entering into searchButton Metho");
        Number id = this.getOrdId();
        DCIteratorBinding iterItem = (DCIteratorBinding)BindingContext.getCurrent().getCurrentBindingsEntry().get("SItemView1Iterator");
        ViewObject vo = iterItem.getViewObject();
        ViewCriteriaManager criteriaManager = vo.getViewCriteriaManager();
        ViewCriteria criteria = criteriaManager.getViewCriteria("SItemViewCriteria");
        vo.setNamedWhereClauseParam("orId", id);
        criteriaManager.applyViewCriteria(criteria);
        vo.executeQuery();
        BigDecimal total = BigDecimal.ZERO;
        while(vo.hasNext()){
            Row row = vo.next();
            Number price = (Number)row.getAttribute("Price");
            Number quantity = (Number)row.getAttribute("Quantity");
            if(price != null && quantity != null){
                total = total.add(new BigDecimal(price.toString()).multiply(new BigDecimal(quantity.toString())));
                
            }
        }
        this.getResult().setValue(total);
        System.out.println("Result....."+this.getResult());
        System.out.println("Exit from searchButton method");
    }

    public void setResult(RichOutputText result) {
        this.result = result;
    }

    public RichOutputText getResult() {
        return result;
    }

    public void setOrdId(Number ordId) {
        this.ordId = ordId;
    }

    public Number getOrdId() {
        return ordId;
    }


//    public void setTotal(BigDecimal total) {
//        this.total = total;
//    }
//
//    public BigDecimal getTotal() {
//        return total;
//    }
}
