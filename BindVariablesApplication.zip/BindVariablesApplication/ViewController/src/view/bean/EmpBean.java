package view.bean;

import javax.faces.context.FacesContext;

import oracle.adf.view.rich.component.rich.input.RichInputText;

public class EmpBean {
    private RichInputText userinoutText;
    private RichInputText jobid;

    public EmpBean() {
        super();
    }

    public String loginAction() {
        // Add event code here...
        Object deptId = this.getUserinoutText().getValue();
        Object jobid = this.getJobid().getValue();
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("userDeptId", deptId);
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("jobId", jobid);
        return "emp";
    }

    public void setUserinoutText(RichInputText userinoutText) {
        this.userinoutText = userinoutText;
    }

    public RichInputText getUserinoutText() {
        return userinoutText;
    }
    
    public void setJobid(RichInputText jobid) {
        this.jobid = jobid;
    }

    public RichInputText getJobid() {
        return jobid;
    }
}
