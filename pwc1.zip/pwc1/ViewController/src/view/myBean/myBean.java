package view.myBean;

import app.model.AppModuleImpl;

import java.math.BigDecimal;


import java.util.ArrayList;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichSelectBooleanCheckbox;
import oracle.adf.view.rich.component.rich.nav.RichCommandToolbarButton;
import oracle.adf.view.rich.component.rich.output.RichOutputText;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.domain.Number;
import oracle.jbo.server.ViewObjectImpl;

public class myBean {
    private RichSelectBooleanCheckbox onselectBind;
    private RichCommandToolbarButton procesBind;
    private RichTable tableBind;
    private RichOutputText totalBind;
    private RichOutputText deptIdValueBind;
    private String arrValues;

    public myBean() {
    }

    public void online(ValueChangeEvent valueChangeEvent) {
        System.out.println("Entering into online======================");
        int i = 0;
        System.out.println("i......."+i);
        Boolean check = (Boolean)valueChangeEvent.getNewValue();
        System.out.println("online Check value: " + check);
        BindingContext bindingContext = BindingContext.getCurrent();
        DCDataControl dc = bindingContext.dataControlFrame().findDataControl("AppModuleDataControl");
        System.out.println("online DCDataControl: " + dc);
        AppModuleImpl appM = (AppModuleImpl)dc.getDataProvider();
        System.out.println("online AppModuleImpl: " + appM);
        ViewObjectImpl empvo = appM.getEmployeesView1();
        System.out.println("online ViewObjectImpl: " + empvo.getQuery());
        empvo.getCurrentRow().setAttribute("SelectBox", check);
        Boolean selflag = false;
        System.out.println("selflag"+selflag);
        if(empvo.getRowCount() > 0){
            Row curRow = empvo.first();
            System.out.println("curRow"+curRow);
            
            for(i = 0; i < empvo.getRowCount(); i++){
                System.out.println("i--------------"+i);
                
                if(curRow.getAttribute("SelectBox") != null){
                    System.out.println("SelectBox"+curRow.getAttribute("SelectBox"));
                    
                    if(curRow.getAttribute("SelectBox").toString().compareTo("true") == 0){
                        System.out.println("SelectBox compareTo"+curRow.getAttribute("SelectBox"));
                        
                        selflag = Boolean.TRUE;
                        System.out.println("selflag"+selflag);
                        
                        break;                            
                    }
                }
                curRow = empvo.next();
            }
        }
        System.out.println("Exit from online========================");
            }

    public void onSelectAll(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        Boolean check = (Boolean)valueChangeEvent.getNewValue();
        System.out.println("Check value: " + check);
        BindingContext bindingContext = BindingContext.getCurrent();
        DCDataControl dc = bindingContext.dataControlFrame().findDataControl("AppModuleDataControl");
        System.out.println("DCDataControl: " + dc);
        AppModuleImpl appM = (AppModuleImpl)dc.getDataProvider();
        System.out.println("AppModuleImpl: " + appM);
        ViewObjectImpl departmentsView1 = appM.getEmployeesView1();
        System.out.println("ViewObjectImpl: " + departmentsView1);
        if(departmentsView1.getCurrentRow() != null){
            if(departmentsView1.getCurrentRow().getAttribute("DepartmentId") == null 
               || departmentsView1.getCurrentRow().getAttribute("DepartmentId") != null){
                appM.handlSelectionCheckBox(check); 
                AdfFacesContext.getCurrentInstance().addPartialTarget(this.getTableBind());
            }
        }
        //AdfFacesContext.getCurrentInstance().addPartialTarget(this.getProcesBind());
//        if(check != null){
//        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getTableBind());
//        if(check == Boolean.TRUE && departmentsView1.getCurrentRow().getAttribute("DepartmentId") != null){
//            this.getProcesBind().setDisabled(false);
//        }else{
//           this.getProcesBind().setDisabled(true); 
//        }
//            this.getProcesBind().setDisabled(true); 
//            AdfFacesContext.getCurrentInstance().addPartialTarget(this.getProcesBind());
//        }
        
    }

    public void setOnselectBind(RichSelectBooleanCheckbox onselectBind) {
        this.onselectBind = onselectBind;
    }

    public RichSelectBooleanCheckbox getOnselectBind() {
        return onselectBind;
    }

    public void proccessButton(ActionEvent actionEvent) {
        // Add event code here...
        System.out.println("Entering into proccessButton+++++++++++++++++++++++++++++++++++++");
        ArrayList<Object> ar = new ArrayList<Object>();
        BindingContext bindingContext = BindingContext.getCurrent();
        DCBindingContainer bindings = (DCBindingContainer)bindingContext.getCurrentBindingsEntry();
        DCIteratorBinding dciter = bindings.findIteratorBinding("EmployeesView1Iterator");
        RowSetIterator rs = dciter.getViewObject().createRowSetIterator(null);
        System.out.println("RowSetIterator.........."+rs);
        BigDecimal totalSalry = BigDecimal.ZERO;
        Number depId = null;
      
        while(rs.hasNext()){
            Row next = rs.next();
            Boolean isSelected = (Boolean)next.getAttribute("SelectBox");
            System.out.println("Selected box is...."+isSelected);
             depId = (Number)next.getAttribute("DepartmentId");
            if(isSelected !=null  && isSelected){
                Number oldsalary = (Number)next.getAttribute("Salary");
               
                System.out.println("oldsalary:- "+oldsalary);
                if(oldsalary != null){
                    BigDecimal salary = new BigDecimal(oldsalary.toString());
                    System.out.println("Total Salaty : = "+salary);
                    if(salary != null){
                        totalSalry = totalSalry.add(salary);
                        //System.out.println("totalSalry = "+totalSalry);
                    }
               
                }
               
            }
            
        }
        //System.out.println("under loop TotalSalary Sum:- "+totalSalry);
        rs.closeRowSetIterator();
        System.out.println("closeRowSetIterator--------------------");
        ar.add(totalSalry);
        ar.add(depId);
        System.out.println("AR.."+ar);
       
        //this.getTotalBind().setValue(totalSalry.toString());
       // System.out.println("Total Salary Summary: \n" + totalSalry);
        //this.getDeptIdValueBind().setValue(depId);
        //System.out.println("Department Id is: " + depId);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getTotalBind());
//        AdfFacesContext.getCurrentInstance().addPartialTarget(this.getTableBind());
        
       setValuesFromArrayList(ar);
        System.out.println("Exit from proccessButton------------------------------------------");
    }


    private void setValuesFromArrayList(ArrayList<Object> arrayList) {
        if (arrayList.size() >= 2) {
            BigDecimal totalSalry = (BigDecimal) arrayList.get(0);
            Number depId = (Number) arrayList.get(1);
            
//            this.getTotalBind().setValue(totalSalry.toString());
//            this.getDeptIdValueBind().setValue(depId);
            this.setArrValues("totalSalry: "+totalSalry+", "+"depId: "+depId);
            //AdfFacesContext.getCurrentInstance().addPartialTarget(this.getArrValues());
//            AdfFacesContext.getCurrentInstance().addPartialTarget(this.getTotalBind());
//            AdfFacesContext.getCurrentInstance().addPartialTarget(this.getTableBind());
        }
    }

    public void setProcesBind(RichCommandToolbarButton procesBind) {
        this.procesBind = procesBind;
    }

    public RichCommandToolbarButton getProcesBind() {
        return procesBind;
    }

    public void setTableBind(RichTable tableBind) {
        this.tableBind = tableBind;
    }

    public RichTable getTableBind() {
        return tableBind;
    }

   

    public void setTotalBind(RichOutputText totalBind) {
        this.totalBind = totalBind;
    }

    public RichOutputText getTotalBind() {
        return totalBind;
    }

    public void setDeptIdValueBind(RichOutputText deptIdValueBind) {
        this.deptIdValueBind = deptIdValueBind;
    }

    public RichOutputText getDeptIdValueBind() {
        return deptIdValueBind;
    }

    public void setArrValues(String arrValues) {
        this.arrValues = arrValues;
    }

    public String getArrValues() {
        return arrValues;
    }
}
